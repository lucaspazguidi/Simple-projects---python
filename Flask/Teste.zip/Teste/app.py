from flask import Flask, render_template, request,  session, redirect, url_for
import random 
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)


@app.route("/home")

def home():
    return render_template("index.html")

@app.route("/adivinhacao")

def adivinhacao():
    return render_template("adivinhacao.html")
@app.route("/inicializar_adivinhar_numero", methods=["POST"])
def inicializar_adivinhar_numero():
    session["numero_adivinhar"] = random.randint(1,100)
    session["numero_tentativa"] = 0
    session["jogo_terminado"] = False
    return render_template("jogo_adivinha.html")
@app.route("/adivinhar_numero", methods=["POST"])
def adivinhar_numero():
    session["numero_escolhido"] = request.form.get("tentativa_adivinha")
    if(int(session.get("numero_escolhido")) == session.get("numero_adivinhar")):
        mensagem = f"Parabens, você acertou o número {session.get("numero_adivinhar")}" 
        session["jogo_terminado"] = True
        return  render_template("jogo_adivinha.html", mensagem = mensagem, jogo_terminado=session.get("jogo_terminado"))
    elif int(session.get("numero_escolhido")) > session.get("numero_adivinhar"):
        session["numero_tentativa"] += 1
        mensagem = f"Palpite muito alto"
        return render_template("jogo_adivinha.html", mensagem = mensagem)
    elif  int(session.get("numero_escolhido")) < session.get("numero_adivinhar"):
        session["numero_tentativa"] += 1
        mensagem = f"Palpite muito baixo"
        return render_template("jogo_adivinha.html", mensagem = mensagem)
    else:
        mensagem = f"Por favor, insira um número inteiro positivo entre 1 e 100"
        return render_template("jogo_adivinha.html", mensagem = mensagem)
        
if __name__ == "__main__":
    app.run(debug=True)