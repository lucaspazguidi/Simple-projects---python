from flask import Flask, render_template, request,  session, redirect, url_for
from random import choice
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)


@app.route("/home")

def home():
    return render_template("index.html")

@app.route("/adivinhacao")

def adivinhacao():
    return render_template("adivinhacao.html")

def inicializar_adivinhar_numero():
    session["numero_adivinhar"] = 5
    session["numero_tentativa"] = 0
    session["jogo_terminado"] = False
    
@app.route("/adivinhar_numero", methods=["POST", "GET"])
def adivinhar_numero():
    if request.method == 'GET':
        inicializar_adivinhar_numero() #reseta
        return render_template("jogo_adivinha.html")
    else:
        acao = request.form.get("acao")
        
        if not session.get("numero_adivinhar"):
            inicializar_adivinhar_numero()
            
        if acao== "novo_jogo" or acao == "init_jogar":
            return render_template("jogo_adivinha.html")
        print(acao)
        
        session["numero_escolhido"] = acao
        print(session.get("numero_escolhido"))
        print(session.get("numero_adivinhar"))
        print(session.get("jogo_terminado"))
        if(int(session.get("numero_escolhido")) == session.get("numero_adivinhar")):
            mensagem = f"Parabens, você acertou o número {session.get("numero_adivinhar")}" 
            session["jogo_terminado"] = True
            return  render_template("jogo_adivinha.html", mensagem = mensagem, jogo_terminado=session.get("jogo_terminado"))
        elif int(session.get("numero_escolhido")) > session.get("numero_adivinhar"):
            session["numero_tentativa"] += 1
            mensagem = f"Palpite muito alto"
            return render_template("jogo_adivinha.html", mensagem = mensagem)
        elif  int(session.get("numero_escolhido")) < session.get("numero_adivinhar"):
            session["numero_tentativa"] += 1
            mensagem = f"Palpite muito baixo"
            return render_template("jogo_adivinha.html", mensagem = mensagem)

        else:
            mensagem = f"Por favor, insira um número inteiro positivo entre 1 e 100"
            return render_template("jogo_adivinha.html", mensagem = mensagem)        
   
if __name__ == "__main__":
    app.run(debug=True)