from flask import Flask, render_template, request, session, redirect, url_for
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)  # necessário para sessões

# Usuários cadastrados (exemplo)
logins = {
    "Eduardo": "123",
    "Sabrina": "12345"
}
@app.route("/")
def home():
    usuario = session.get("nome")  # pega usuário logado, se houver
    logado = bool(usuario)
    return render_template("index.html", usuario=usuario, logado = logado)

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        nome = request.form.get("nome-usuario")
        senha = request.form.get("senha-usuario")

        if nome in logins and logins[nome] == senha:
            session["nome"] = nome  # salva usuário na sessão
            return redirect(url_for("home"))
        else:
            return "Login inválido"
    return render_template("login.html")

@app.route("/cadastro")
def cadastro():
    return render_template("cadastro.html")

@app.route("/logout")
def logout():
    session.pop("nome", None)  # remove usuário da sessão
    return redirect(url_for("home"))

if __name__ == "__main__":
    app.run(debug=True)
